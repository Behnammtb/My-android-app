package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.AmpStories
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.ui.graphics.vector.ImageVector

enum class ContentType(
  val id: String,
  val titleFa: String,
  val subtitleFa: String,
  val icon: ImageVector,
  val tagFa: String
) {
  INSTAGRAM_POST(
    id = "instagram_post",
    titleFa = "پست اسلایدی اینستاگرام",
    subtitleFa = "اسلایدهای آموزشی و متنی",
    icon = Icons.Default.PhotoCamera,
    tagFa = "اسلاید & کاروسل"
  ),
  CAPTION(
    id = "caption",
    titleFa = "کپشن جذاب و درگیرکننده",
    subtitleFa = "قلاب، بدنه، فراخوان عمل و هشتگ",
    icon = Icons.Default.ChatBubbleOutline,
    tagFa = "کپشن اینستاگرام"
  ),
  REELS_SCRIPT(
    id = "reels_script",
    titleFa = "سناریوی ریلز و شورتس",
    subtitleFa = "۳ ثانیه اول، بدنه و زاویه دوربین",
    icon = Icons.Default.MovieCreation,
    tagFa = "ویدیو و ریلز"
  ),
  INSTAGRAM_STORY(
    id = "instagram_story",
    titleFa = "استوری تعاملی و فروش",
    subtitleFa = "نظرسنجی، باکس سوال و سناریوی استوری",
    icon = Icons.Default.AmpStories,
    tagFa = "استوری زنجیره‌ای"
  ),
  BLOG_POST(
    id = "blog_post",
    titleFa = "مقاله سئو وبلاگ",
    subtitleFa = "مقدمه جذاب، سرفصل H2/H3 و نتیجه‌گیری",
    icon = Icons.AutoMirrored.Filled.Article,
    tagFa = "مقاله و سئو"
  ),
  THREAD(
    id = "thread",
    titleFa = "رشته توییت / تردز",
    subtitleFa = "توییت اول ویروسی و نکات پیوسته",
    icon = Icons.Default.Campaign,
    tagFa = "توییتر و تردز"
  ),
  EMAIL_MARKETING(
    id = "email_marketing",
    titleFa = "ایمیل مارکتینگ و خبرنامه",
    subtitleFa = "عنوان بازشونده، محتوا و ترغیب به خرید",
    icon = Icons.Default.MailOutline,
    tagFa = "ایمیل و خبرنامه"
  ),
  PRODUCT_DESCRIPTION(
    id = "product_description",
    titleFa = "توضیحات و فروش محصول",
    subtitleFa = "مزایای رقابتی، رفع اعتراض و پیشنهاد ویژه",
    icon = Icons.Default.ShoppingBag,
    tagFa = "فروشگاهی"
  )
}
