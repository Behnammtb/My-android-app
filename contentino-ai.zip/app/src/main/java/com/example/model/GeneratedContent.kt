package com.example.model

data class GeneratedContent(
  val id: String,
  val topic: String,
  val niche: Niche,
  val contentType: ContentType,
  val tone: ContentTone,
  val titleFa: String,
  val hookFa: String,
  val bodyFa: String,
  val callToActionFa: String,
  val hashtags: List<String>,
  val wordCount: Int,
  val estimatedReadingSeconds: Int,
  val createdAtTimestamp: Long = System.currentTimeMillis(),
  val isFavorite: Boolean = false
) {
  fun getFullFormattedText(): String {
    val builder = StringBuilder()
    builder.append("✨ ").append(titleFa).append("\n\n")
    if (hookFa.isNotBlank()) {
      builder.append("🎯 قلاب جذب مخاطب:\n").append(hookFa).append("\n\n")
    }
    builder.append("📝 متن اصلی:\n").append(bodyFa).append("\n\n")
    if (callToActionFa.isNotBlank()) {
      builder.append("🚀 کال تو اکشن (CTA):\n").append(callToActionFa).append("\n\n")
    }
    if (hashtags.isNotEmpty()) {
      builder.append("🏷️ هشتگ‌ها:\n").append(hashtags.joinToString(" ")).append("\n")
    }
    return builder.toString()
  }
}
