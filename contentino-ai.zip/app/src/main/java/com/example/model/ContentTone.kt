package com.example.model

enum class ContentTone(
  val id: String,
  val titleFa: String,
  val emoji: String,
  val descriptionFa: String
) {
  FRIENDLY(
    id = "friendly",
    titleFa = "صمیمی و خودمانی",
    emoji = "💬",
    descriptionFa = "لحن گرم، صمیمانه و نزدیک به مخاطب"
  ),
  PROFESSIONAL(
    id = "professional",
    titleFa = "رسمی و تخصصی",
    emoji = "💼",
    descriptionFa = "ادبیات معتبر، دقیق و کسب‌وکاری"
  ),
  ENERGETIC(
    id = "energetic",
    titleFa = "پرانرژی و هیجانی",
    emoji = "🔥",
    descriptionFa = "ریتم تند، کلمات مهیج و شورانگیز"
  ),
  MOTIVATIONAL(
    id = "motivational",
    titleFa = "انگیزشی و تحول‌آفرین",
    emoji = "🌟",
    descriptionFa = "الهام‌بخش، تقویت اراده و باور به خود"
  ),
  EDUCATIONAL(
    id = "educational",
    titleFa = "آموزشی و قدم‌به‌قدم",
    emoji = "🎯",
    descriptionFa = "ساختارمند، گام‌به‌گام و شفاف"
  )
}
