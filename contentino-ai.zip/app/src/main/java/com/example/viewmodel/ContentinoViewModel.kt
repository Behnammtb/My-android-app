package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.generator.PersianContentEngine
import com.example.model.ContentTone
import com.example.model.ContentType
import com.example.model.GeneratedContent
import com.example.model.Niche
import com.example.model.NicheRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ContentinoViewModel : ViewModel() {

  private val _niches = NicheRepository.niches
  val niches: List<Niche> = _niches

  private var currentNicheIndex = 0
  private val _selectedNiche = MutableStateFlow(_niches[0])
  val selectedNiche: StateFlow<Niche> = _selectedNiche.asStateFlow()

  private val _isAutoCycling = MutableStateFlow(true)
  val isAutoCycling: StateFlow<Boolean> = _isAutoCycling.asStateFlow()

  private var cycleJob: Job? = null

  private val _selectedContentType = MutableStateFlow(ContentType.INSTAGRAM_POST)
  val selectedContentType: StateFlow<ContentType> = _selectedContentType.asStateFlow()

  private val _selectedTone = MutableStateFlow(ContentTone.FRIENDLY)
  val selectedTone: StateFlow<ContentTone> = _selectedTone.asStateFlow()

  private val _topicInput = MutableStateFlow("")
  val topicInput: StateFlow<String> = _topicInput.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  private val _generatedContent = MutableStateFlow<GeneratedContent?>(null)
  val generatedContent: StateFlow<GeneratedContent?> = _generatedContent.asStateFlow()

  private val _history = MutableStateFlow<List<GeneratedContent>>(emptyList())
  val history: StateFlow<List<GeneratedContent>> = _history.asStateFlow()

  private val _toastMessage = MutableStateFlow<String?>(null)
  val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

  init {
    startAutoCycling()
  }

  fun setTopic(text: String) {
    _topicInput.value = text
  }

  fun selectContentType(type: ContentType) {
    _selectedContentType.value = type
  }

  fun selectNiche(niche: Niche) {
    val idx = _niches.indexOfFirst { it.id == niche.id }
    if (idx != -1) {
      currentNicheIndex = idx
    }
    _selectedNiche.value = niche
  }

  fun cycleToNextNiche() {
    currentNicheIndex = (currentNicheIndex + 1) % _niches.size
    _selectedNiche.value = _niches[currentNicheIndex]
  }

  fun cycleToPreviousNiche() {
    currentNicheIndex = if (currentNicheIndex - 1 < 0) _niches.size - 1 else currentNicheIndex - 1
    _selectedNiche.value = _niches[currentNicheIndex]
  }

  fun toggleAutoCycle() {
    val newValue = !_isAutoCycling.value
    _isAutoCycling.value = newValue
    if (newValue) {
      startAutoCycling()
      _toastMessage.value = "چرخش خودکار حوزه فعال شد"
    } else {
      stopAutoCycling()
      _toastMessage.value = "چرخش خودکار حوزه متوقف شد"
    }
  }

  private fun startAutoCycling() {
    cycleJob?.cancel()
    cycleJob = viewModelScope.launch {
      while (isActive) {
        delay(4000L)
        if (_isAutoCycling.value) {
          cycleToNextNiche()
        }
      }
    }
  }

  private fun stopAutoCycling() {
    cycleJob?.cancel()
    cycleJob = null
  }

  fun selectTone(tone: ContentTone) {
    _selectedTone.value = tone
  }

  fun pickSampleTopic(sample: String) {
    _topicInput.value = sample
  }

  fun clearTopic() {
    _topicInput.value = ""
  }

  fun generateContent() {
    viewModelScope.launch {
      _isGenerating.value = true
      // Realistic brief AI synthesis delay for smooth visual feedback
      delay(750L)

      val content = PersianContentEngine.generate(
        topic = _topicInput.value,
        niche = _selectedNiche.value,
        contentType = _selectedContentType.value,
        tone = _selectedTone.value
      )

      _generatedContent.value = content
      _history.value = listOf(content) + _history.value.filter { it.id != content.id }
      _isGenerating.value = false
      _toastMessage.value = "محتوای هوشمند با موفقیت تولید شد ✨"
    }
  }

  fun regenerateContent() {
    generateContent()
  }

  fun toggleFavorite(id: String) {
    val current = _generatedContent.value
    if (current != null && current.id == id) {
      _generatedContent.value = current.copy(isFavorite = !current.isFavorite)
    }
    _history.value = _history.value.map { item ->
      if (item.id == id) item.copy(isFavorite = !item.isFavorite) else item
    }
  }

  fun deleteFromHistory(id: String) {
    _history.value = _history.value.filter { it.id != id }
    if (_generatedContent.value?.id == id) {
      _generatedContent.value = null
    }
    _toastMessage.value = "محتوا از تاریخچه حذف شد"
  }

  fun showToast(message: String) {
    _toastMessage.value = message
  }

  fun dismissToast() {
    _toastMessage.value = null
  }
}
