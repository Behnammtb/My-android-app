package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Niche
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SecondaryPink
import com.example.ui.theme.TertiaryCyan

@Composable
fun NicheCyclingCard(
  selectedNiche: Niche,
  allNiches: List<Niche>,
  isAutoCycling: Boolean,
  onNicheSelected: (Niche) -> Unit,
  onNextNiche: () -> Unit,
  onPrevNiche: () -> Unit,
  onToggleAutoCycle: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
    ),
    border = BorderStroke(
      width = 1.dp,
      brush = Brush.horizontalGradient(
        listOf(
          IndigoPrimary.copy(alpha = 0.5f),
          SecondaryPink.copy(alpha = 0.4f),
          TertiaryCyan.copy(alpha = 0.5f)
        )
      )
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Top status row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = CircleShape,
            color = IndigoPrimary.copy(alpha = 0.18f),
            modifier = Modifier.size(32.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Autorenew,
                contentDescription = null,
                tint = IndigoPrimary,
                modifier = Modifier.size(18.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "حوزه فعالیت در حال چرخش",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        // Auto cycling toggle badge
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (isAutoCycling) AccentAmber.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
          border = BorderStroke(
            1.dp,
            if (isAutoCycling) AccentAmber.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          ),
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onToggleAutoCycle)
            .testTag("toggle_auto_cycle_button")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = if (isAutoCycling) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = if (isAutoCycling) "توقف چرخش" else "شروع چرخش",
              tint = if (isAutoCycling) AccentAmber else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isAutoCycling) "چرخش خودکار" else "متوقف شده",
              style = MaterialTheme.typography.labelSmall,
              color = if (isAutoCycling) AccentAmber else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Animated current niche showcase
      AnimatedContent(
        targetState = selectedNiche,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "niche_content"
      ) { niche ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
              Brush.linearGradient(
                listOf(
                  IndigoPrimary.copy(alpha = 0.12f),
                  MaterialTheme.colorScheme.surface
                )
              )
            )
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = MaterialTheme.colorScheme.surface,
              shadowElevation = 2.dp,
              modifier = Modifier.size(48.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(
                  text = niche.emoji,
                  fontSize = 24.sp
                )
              }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
              Text(
                text = niche.nameFa,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = niche.descriptionFa,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
              )
            }
          }

          // Cycle controls
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            IconButton(
              onClick = onPrevNiche,
              modifier = Modifier
                .size(36.dp)
                .testTag("niche_prev_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "حوزه قبلی",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
              )
            }

            IconButton(
              onClick = onNextNiche,
              modifier = Modifier
                .size(36.dp)
                .testTag("niche_next_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "حوزه بعدی",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Horizontal quick-select chips for all niches
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        allNiches.forEach { niche ->
          val isSelected = niche.id == selectedNiche.id
          AssistChip(
            onClick = { onNicheSelected(niche) },
            label = {
              Text(
                text = "${niche.emoji} ${niche.nameFa}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = AssistChipDefaults.assistChipColors(
              containerColor = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.surface,
              labelColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
            ),
            border = BorderStroke(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("niche_chip_${niche.id}")
          )
        }
      }
    }
  }
}
