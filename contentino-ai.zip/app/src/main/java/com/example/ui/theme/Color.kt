package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors: Indigo & Violet
val IndigoPrimary = Color(0xFF6366F1)
val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoPrimaryLight = Color(0xFF4338CA)

val SecondaryPink = Color(0xFFEC4899)
val SecondaryPinkDark = Color(0xFFF472B6)

val TertiaryCyan = Color(0xFF06B6D4)
val TertiaryCyanDark = Color(0xFF22D3EE)

val AccentAmber = Color(0xFFF59E0B)
val AccentEmerald = Color(0xFF10B981)

// Dark Theme Surfaces (Deep Slate & Midnight Indigo)
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF252D4A)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF334155)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF64748B)
val LightBorder = Color(0xFFE2E8F0)
