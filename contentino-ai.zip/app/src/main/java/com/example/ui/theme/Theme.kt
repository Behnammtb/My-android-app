package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = IndigoPrimaryDark,
  onPrimary = Color.White,
  primaryContainer = IndigoPrimaryLight,
  onPrimaryContainer = Color.White,
  secondary = SecondaryPinkDark,
  onSecondary = Color.Black,
  secondaryContainer = Color(0xFF701A75),
  onSecondaryContainer = Color.White,
  tertiary = TertiaryCyanDark,
  onTertiary = Color.Black,
  background = DarkBackground,
  onBackground = DarkOnSurface,
  surface = DarkSurface,
  onSurface = DarkOnSurface,
  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = DarkOnSurfaceVariant,
  outline = DarkBorder
)

private val LightColorScheme = lightColorScheme(
  primary = IndigoPrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0E7FF),
  onPrimaryContainer = IndigoPrimaryLight,
  secondary = SecondaryPink,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFFCE7F3),
  onSecondaryContainer = Color(0xFF831843),
  tertiary = TertiaryCyan,
  onTertiary = Color.White,
  background = LightBackground,
  onBackground = LightOnSurface,
  surface = LightSurface,
  onSurface = LightOnSurface,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = LightOnSurfaceVariant,
  outline = LightBorder
)

@Composable
fun ContentinoTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color can be toggled; for strong brand identity we default to false or dynamic
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
