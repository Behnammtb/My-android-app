package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GeneratedContent
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SecondaryPink
import com.example.ui.theme.TertiaryCyan
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeneratedResultCard(
  content: GeneratedContent,
  onRegenerate: () -> Unit,
  onToggleFavorite: (String) -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var isCopied by remember { mutableStateOf(false) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("generated_result_card"),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    border = BorderStroke(
      width = 1.5.dp,
      brush = Brush.horizontalGradient(
        listOf(
          IndigoPrimary.copy(alpha = 0.6f),
          SecondaryPink.copy(alpha = 0.4f),
          TertiaryCyan.copy(alpha = 0.6f)
        )
      )
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      // Header badge row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = IndigoPrimary.copy(alpha = 0.15f)
          ) {
            Text(
              text = "${content.niche.emoji} ${content.niche.nameFa}",
              style = MaterialTheme.typography.labelSmall,
              color = IndigoPrimary,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = SecondaryPink.copy(alpha = 0.15f)
          ) {
            Text(
              text = content.contentType.tagFa,
              style = MaterialTheme.typography.labelSmall,
              color = SecondaryPink,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }

        IconButton(
          onClick = { onToggleFavorite(content.id) },
          modifier = Modifier.size(36.dp)
        ) {
          Icon(
            imageVector = if (content.isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
            contentDescription = "ذخیره در نشان‌شده‌ها",
            tint = if (content.isFavorite) AccentAmber else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Content Title
      Text(
        text = content.titleFa,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )

      // Meta Stats (Words & Reading Time)
      Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = "📊 ${content.wordCount} کلمه",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "⏱️ حدود ${content.estimatedReadingSeconds} ثانیه زمان مطالعه",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      HorizontalDivider(
        modifier = Modifier.padding(vertical = 10.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
      )

      // Hook Section
      if (content.hookFa.isNotBlank()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(IndigoPrimary.copy(alpha = 0.08f))
            .padding(12.dp)
        ) {
          Column {
            Text(
              text = "🎯 قلاب جلب توجه (Hook):",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = IndigoPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = content.hookFa,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface,
              lineHeight = 22.sp
            )
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      // Body Section
      Text(
        text = content.bodyFa,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 26.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Call to action Section
      if (content.callToActionFa.isNotBlank()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SecondaryPink.copy(alpha = 0.08f))
            .padding(12.dp)
        ) {
          Column {
            Text(
              text = "🚀 فراخوان عمل (Call To Action):",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = SecondaryPink
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = content.callToActionFa,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface,
              lineHeight = 22.sp
            )
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      // Hashtags
      if (content.hashtags.isNotEmpty()) {
        Text(
          text = "🏷️ هشتگ‌های پیشنهادی:",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          content.hashtags.forEach { tag ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.clickable {
                copyToClipboard(context, tag)
                onShowMessage("هشتگ $tag کپی شد")
              }
            ) {
              Text(
                text = tag,
                style = MaterialTheme.typography.labelSmall,
                color = TertiaryCyan,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }
      }

      HorizontalDivider(
        modifier = Modifier.padding(vertical = 14.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
      )

      // Actions Footer
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Copy Button
        FilledTonalButton(
          onClick = {
            copyToClipboard(context, content.getFullFormattedText())
            isCopied = true
            onShowMessage("متن کامل با موفقیت کپی شد 📋")
            scope.launch {
              delay(2000L)
              isCopied = false
            }
          },
          modifier = Modifier
            .weight(1f)
            .testTag("copy_content_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (isCopied) AccentEmerald.copy(alpha = 0.2f) else IndigoPrimary.copy(alpha = 0.15f),
            contentColor = if (isCopied) AccentEmerald else IndigoPrimary
          )
        ) {
          Icon(
            imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isCopied) "کپی شد!" else "کپی متن",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
        }

        // Share Button
        OutlinedButton(
          onClick = {
            shareContent(context, content.getFullFormattedText(), content.titleFa)
          },
          modifier = Modifier
            .weight(1f)
            .testTag("share_content_button"),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "اشتراک",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
        }

        // Regenerate Button
        IconButton(
          onClick = onRegenerate,
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .testTag("regenerate_button")
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "تولید مجدد",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

private fun copyToClipboard(context: Context, text: String) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val clip = ClipData.newPlainText("Contentino Content", text)
  clipboard.setPrimaryClip(clip)
}

private fun shareContent(context: Context, text: String, title: String) {
  val sendIntent = Intent().apply {
    action = Intent.ACTION_SEND
    putExtra(Intent.EXTRA_TEXT, text)
    putExtra(Intent.EXTRA_TITLE, title)
    type = "text/plain"
  }
  val shareIntent = Intent.createChooser(sendIntent, "ارسال محتوا با")
  context.startActivity(shareIntent)
}
