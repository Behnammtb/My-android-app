package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ContentTypeSelector
import com.example.ui.components.GenerateActionButton
import com.example.ui.components.GeneratedResultCard
import com.example.ui.components.HistoryBottomSheet
import com.example.ui.components.NicheCyclingCard
import com.example.ui.components.TopicInputSection
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SecondaryPink
import com.example.ui.theme.TertiaryCyan
import com.example.viewmodel.ContentinoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: ContentinoViewModel,
  modifier: Modifier = Modifier
) {
  // Explicitly ensure Persian RTL direction across the entire layout
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    val selectedNiche by viewModel.selectedNiche.collectAsState()
    val isAutoCycling by viewModel.isAutoCycling.collectAsState()
    val selectedContentType by viewModel.selectedContentType.collectAsState()
    val selectedTone by viewModel.selectedTone.collectAsState()
    val topicInput by viewModel.topicInput.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val generatedContent by viewModel.generatedContent.collectAsState()
    val history by viewModel.history.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var showHistorySheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val scrollState = rememberScrollState()

    LaunchedEffect(toastMessage) {
      toastMessage?.let { msg ->
        snackbarHostState.showSnackbar(msg)
        viewModel.dismissToast()
      }
    }

    // Scroll down to newly generated content when generated
    LaunchedEffect(generatedContent) {
      if (generatedContent != null) {
        scrollState.animateScrollTo(scrollState.maxValue)
      }
    }

    Scaffold(
      modifier = modifier.fillMaxSize(),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        CenterAlignedTopAppBar(
          title = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Surface(
                shape = CircleShape,
                color = IndigoPrimary,
                modifier = Modifier.size(32.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = "کانتنتینو AI",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "دستیار هوشمند تولید محتوای فارسی",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  fontSize = 10.sp
                )
              }
            }
          },
          actions = {
            IconButton(
              onClick = { showHistorySheet = true },
              modifier = Modifier.testTag("history_button")
            ) {
              BadgedBox(
                badge = {
                  if (history.isNotEmpty()) {
                    Badge(
                      containerColor = SecondaryPink,
                      contentColor = Color.White
                    ) {
                      Text(history.size.toString())
                    }
                  }
                }
              ) {
                Icon(
                  imageVector = Icons.Default.History,
                  contentDescription = "تاریخچه محتوا",
                  tint = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          },
          colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
          )
        )
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .background(
            Brush.verticalGradient(
              listOf(
                MaterialTheme.colorScheme.surface,
                MaterialTheme.colorScheme.background
              )
            )
          ),
        contentAlignment = Alignment.TopCenter
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 680.dp)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          // 1. Cycling Niche Section
          NicheCyclingCard(
            selectedNiche = selectedNiche,
            allNiches = viewModel.niches,
            isAutoCycling = isAutoCycling,
            onNicheSelected = { viewModel.selectNiche(it) },
            onNextNiche = { viewModel.cycleToNextNiche() },
            onPrevNiche = { viewModel.cycleToPreviousNiche() },
            onToggleAutoCycle = { viewModel.toggleAutoCycle() }
          )

          // 2. Content Type Selector
          ContentTypeSelector(
            selectedType = selectedContentType,
            onTypeSelected = { viewModel.selectContentType(it) }
          )

          // 3. Topic Input & Suggestions Section
          TopicInputSection(
            topic = topicInput,
            selectedNiche = selectedNiche,
            selectedTone = selectedTone,
            onTopicChange = { viewModel.setTopic(it) },
            onClearTopic = { viewModel.clearTopic() },
            onSelectSampleTopic = { viewModel.pickSampleTopic(it) },
            onToneSelected = { viewModel.selectTone(it) },
            onDoneKeyboard = { viewModel.generateContent() }
          )

          // 4. Prominent Generate Button
          GenerateActionButton(
            isGenerating = isGenerating,
            onGenerateClick = { viewModel.generateContent() }
          )

          // 5. Result Display Area
          AnimatedVisibility(
            visible = generatedContent != null,
            enter = fadeIn() + slideInVertically(initialOffsetY = { 80 }),
            exit = fadeOut()
          ) {
            generatedContent?.let { content ->
              GeneratedResultCard(
                content = content,
                onRegenerate = { viewModel.regenerateContent() },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                onShowMessage = { viewModel.showToast(it) },
                modifier = Modifier.padding(top = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(32.dp))
        }
      }

      if (showHistorySheet) {
        HistoryBottomSheet(
          sheetState = sheetState,
          history = history,
          onDismiss = { showHistorySheet = false },
          onSelectContent = { item ->
            viewModel.selectNiche(item.niche)
            viewModel.selectContentType(item.contentType)
            viewModel.setTopic(item.topic)
          },
          onDeleteContent = { viewModel.deleteFromHistory(it) }
        )
      }
    }
  }
}
