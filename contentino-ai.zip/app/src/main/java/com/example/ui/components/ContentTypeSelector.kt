package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentType
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SecondaryPink

@Composable
fun ContentTypeSelector(
  selectedType: ContentType,
  onTypeSelected: (ContentType) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "انتخاب قالب و نوع محتوا",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = IndigoPrimary.copy(alpha = 0.12f)
      ) {
        Text(
          text = "${selectedType.tagFa}",
          style = MaterialTheme.typography.labelSmall,
          color = IndigoPrimary,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // 2-column grid of content types
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      val types = ContentType.values()
      for (i in types.indices step 2) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          val type1 = types[i]
          ContentTypeCard(
            contentType = type1,
            isSelected = type1 == selectedType,
            onSelect = { onTypeSelected(type1) },
            modifier = Modifier.weight(1f)
          )

          if (i + 1 < types.size) {
            val type2 = types[i + 1]
            ContentTypeCard(
              contentType = type2,
              isSelected = type2 == selectedType,
              onSelect = { onTypeSelected(type2) },
              modifier = Modifier.weight(1f)
            )
          } else {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }
  }
}

@Composable
private fun ContentTypeCard(
  contentType: ContentType,
  isSelected: Boolean,
  onSelect: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onSelect)
      .testTag("content_type_${contentType.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) {
        IndigoPrimary.copy(alpha = 0.14f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    border = BorderStroke(
      width = if (isSelected) 1.8.dp else 1.dp,
      brush = if (isSelected) {
        Brush.horizontalGradient(listOf(IndigoPrimary, SecondaryPink))
      } else {
        Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)))
      }
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 0.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.size(38.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = contentType.icon,
            contentDescription = contentType.titleFa,
            tint = if (isSelected) Color.White else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = contentType.titleFa,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
          color = if (isSelected) IndigoPrimary else MaterialTheme.colorScheme.onSurface,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = contentType.subtitleFa,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 11.sp,
          maxLines = 1
        )
      }

      if (isSelected) {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = "انتخاب شده",
          tint = IndigoPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}
