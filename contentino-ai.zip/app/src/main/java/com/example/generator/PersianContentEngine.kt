package com.example.generator

import com.example.model.ContentTone
import com.example.model.ContentType
import com.example.model.GeneratedContent
import com.example.model.Niche
import java.util.UUID

object PersianContentEngine {

  fun generate(
    topic: String,
    niche: Niche,
    contentType: ContentType,
    tone: ContentTone
  ): GeneratedContent {
    val cleanTopic = if (topic.isBlank()) {
      niche.sampleTopics.random()
    } else {
      topic.trim()
    }

    val title = when (contentType) {
      ContentType.INSTAGRAM_POST -> "اسلایدر حرفه‌ای: $cleanTopic"
      ContentType.CAPTION -> "کپشن پرتعامل: $cleanTopic"
      ContentType.REELS_SCRIPT -> "سناریوی میلیونی ریلز: $cleanTopic"
      ContentType.INSTAGRAM_STORY -> "زنجیره استوری تعاملی: $cleanTopic"
      ContentType.BLOG_POST -> "راهنمای جامع و سئوشده: $cleanTopic"
      ContentType.THREAD -> "رشته توییت کاربردی درباره: $cleanTopic"
      ContentType.EMAIL_MARKETING -> "ایمیل و خبرنامه ویژه: $cleanTopic"
      ContentType.PRODUCT_DESCRIPTION -> "معرفی ارزش و ویژگی‌های: $cleanTopic"
    }

    val hook = generateHook(cleanTopic, contentType, tone, niche)
    val body = generateBody(cleanTopic, contentType, tone, niche)
    val cta = generateCta(contentType, tone)
    val hashtags = generateHashtags(cleanTopic, niche, contentType)

    val fullText = "$title\n$hook\n$body\n$cta\n${hashtags.joinToString(" ")}"
    val wordCount = fullText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
    val estimatedReadingSeconds = (wordCount * 0.4).toInt().coerceAtLeast(15)

    return GeneratedContent(
      id = UUID.randomUUID().toString(),
      topic = cleanTopic,
      niche = niche,
      contentType = contentType,
      tone = tone,
      titleFa = title,
      hookFa = hook,
      bodyFa = body,
      callToActionFa = cta,
      hashtags = hashtags,
      wordCount = wordCount,
      estimatedReadingSeconds = estimatedReadingSeconds
    )
  }

  private fun generateHook(topic: String, type: ContentType, tone: ContentTone, niche: Niche): String {
    return when (type) {
      ContentType.REELS_SCRIPT -> {
        """🎬 [ثانیه ۰ تا ۳ - جلوی دوربین با صدای رسا و زبان بدن محکم]:
«اگه هنوز فکر می‌کنی $topic سخته یا زمان‌بره، فقط تا آخر این ویدیو همراه من باش تا یه راز ناگفته رو بهت نشون بدم!»"""
      }
      ContentType.INSTAGRAM_POST -> {
        """📌 [اسلاید ۱ - تصویر کاور با فونت درشت و کنتراست بالا]:
«چرا ۹۰٪ افراد در مورد $topic اشتباه فکر می‌کنند؟ (ورق بزنید و فرمول درستش رو یاد بگیرید)»"""
      }
      ContentType.CAPTION -> {
        """🔥 قبل از اینکه این پست رو رد کنی، دستت رو نگه دار!
خیلی وقت بود می‌خواستم خیلی رک و بی‌پرده درباره $topic باهاتون صحبت کنم..."""
      }
      ContentType.INSTAGRAM_STORY -> {
        """⚡ استوری ۱ (کنجکاوی‌ساز):
«امروز یه تجربه‌ای داشتم که نظرم رو در مورد $topic کاملاً زیر و رو کرد... می‌خواید بدونید چی شد؟ (استیکر نظرسنجی: آره بگو / نه کنجکاو نیستم)»"""
      }
      ContentType.THREAD -> {
        """🧵 ۱/۶ | احتمالاً بارها درباره «$topic» شنیدید، اما کسی نقشه راه عملی بهتون نداده.
توی این رشته، گام‌به‌گام و خلاصه همه‌چیز رو براتون می‌شکافم:👇"""
      }
      ContentType.BLOG_POST -> {
        """آیا به دنبال درک عمیق و کاربردی از $topic هستید؟ در این مقاله تخصصی در حوزه ${niche.nameFa}، تمام فوت‌وفن‌ها و مراحل کلیدی را بررسی کرده‌ایم."""
      }
      ContentType.EMAIL_MARKETING -> {
        """موضوع ایمیل (Subject): فرصت ویژه برای مسلط شدن بر $topic 🚀
پیش‌نمایش: این ایمیل شاید تنها چیزی باشه که این هفته برای پیشرفت نیاز داری."""
      }
      ContentType.PRODUCT_DESCRIPTION -> {
        """آیا به دنبال راه‌حلی قطعی، سریع و آزموده‌شده برای $topic هستید؟ وقتشه با روش‌های قدیمی و خسته‌کننده خداحافظی کنید!"""
      }
    }
  }

  private fun generateBody(topic: String, type: ContentType, tone: ContentTone, niche: Niche): String {
    val toneModifier = when (tone) {
      ContentTone.FRIENDLY -> "ببین رفیق، واقعیت اینه که"
      ContentTone.PROFESSIONAL -> "بر اساس اصول و استانداردهای روز،"
      ContentTone.ENERGETIC -> "آماده باش چون قراره بترکونیم!"
      ContentTone.MOTIVATIONAL -> "یادت باشه بزرگ‌ترین موفقیت‌ها از یک تصمیم شجاعانه شروع شدن:"
      ContentTone.EDUCATIONAL -> "اگر بخواهیم به صورت دسته‌بندی‌شده و شفاف بررسی کنیم:"
    }

    return when (type) {
      ContentType.INSTAGRAM_POST -> {
        """$toneModifier موضوع «$topic» به چند مرحله کلیدی تقسیم میشه:

📑 اسلاید ۲ | نقطه شروع و تشخیص مسئله:
ابتدا باید ببینید در کجای مسیر قرار دارید. بدون شناخت دقیق نیاز مخاطب در حوزه ${niche.nameFa}، هیچ استراتژی موفقی شکل نمی‌گیره.

📑 اسلاید ۳ | ابزارها و تکنیک‌های پیاده‌سازی:
• گام اول: اولویت‌بندی اهداف کوتاه‌مدت
• گام دوم: استفاده از چک‌لیست‌های کاربردی و سیستماتیک
• گام سوم: ارزیابی مداوم نتایج و رفع سریع باگ‌ها

📑 اسلاید ۴ | خطای رایجی که باید ازش دوری کنید:
خیلی‌ها از روز اول دنبال بی‌نقص بودن هستند؛ در حالی که استمرار و تست مداوم، راز اصلی تمایز شماست!

📑 اسلاید ۵ | جمع‌بندی طلایی:
با تکرار منظم این ۳ گام، کیفیت کار شما حداقل ۳ برابر رشد خواهد کرد."""
      }

      ContentType.CAPTION -> {
        """$toneModifier خیلی وقت‌ها ما پیچیدگی‌های بی‌دلیل درست می‌کنیم، در حالی که مسیر موفقیت در «$topic» بسیار شفاف‌تر از اون چیزیه که فکرش رو می‌کنی.

✨ ۳ نکته مهم که باید به خاطر بسپاری:
۱️⃣ تمرکز روی ارزش واقعی: به جای حاشیه‌ها، روی اصل مطلبی که مشکل مخاطب رو حل می‌کنه سرمایه‌گذاری کن.
۲️⃣ نظم و استمرار: کاری که هر روز انجام بشه، اثر مرکب باورنکردنی ایجاد می‌کنه.
۳️⃣ استفاده از ابزارهای نوآورانه: در دنیای سریع امروز در زمینه ${niche.nameFa}، هوشمندانه‌تر کار کن، نه سخت‌تر!

شما تا حالا در مورد این موضوع چه تجربه‌ای داشتید؟ چالش اصلی‌تون کجاست؟ برام بنویسید تا با هم گپ بزنیم👇"""
      }

      ContentType.REELS_SCRIPT -> {
        """🎥 [سناریوی ۳۰ ثانیه‌ای ریلز]:

⏱️ [ثانیه ۳ تا ۱۰ - معرفی راهکار / تغییر زاویه دوربین]:
(با دست به روی متن اشاره کنید) «ببینید، برای اینکه $topic رو در حوزه ${niche.nameFa} بدون سردرگمی اجرا کنید، نیازی به کارهای عجیب‌وغریب ندارید. فقط این ۲ مرحله رو مو‌به‌مو انجام بدید:»

⏱️ [ثانیه ۱۰ تا ۲۲ - اجرای زنده یا نمایش اسکرین]:
«مرحله اول: این ابزار رایگان رو باز کنید و ورودی اصلی‌تون رو وارد کنید.
مرحله دوم: خروجی رو با این فیلتر اختصاصی چک کنید تا نرخ اثربخشی تا ۸۰٪ بره بالا!»

⏱️ [ثانیه ۲۲ تا ۳۰ - نتیجه و کات سریع]:
«دیدید چقدر ساده بود؟ اگر می‌خواید لیست کامل منابع رو براتون دایرکت بفرستم، کلمه "راهنما" رو کامنت کنید!»"""
      }

      ContentType.INSTAGRAM_STORY -> {
        """📱 [سناریوی زنجیره استوری ۴ مرحله‌ای]:

🔹 استوری ۱ (ایجاد کنجکاوی و درد مشترک):
عکس در حال کار + متن: «امروز وقتی داشتم روی پروژه $topic کار می‌کردم، متوجه یه الگوی جالب شدم...»

🔹 استوری ۲ (نظرسنجی مخاطب):
«به نظر شما بزرگ‌ترین چالش در ${niche.nameFa} کدومه؟»
[گزینه ۱: کمبود وقت و ایده | گزینه ۲: بلد نبودن تکنیک‌ها]

🔹 استوری ۳ (ارائه راهکار کلیدی و پشت صحنه):
یک اسکرین‌شات یا ویدیوی کوتاه از مانیتور با توضیح متنی مختصر درباره راهکار $topic.

🔹 استوری ۴ (کال تو اکشن مستقیم):
«لینک مستقیم ابزار یا فایل آموزشی رو گذاشتم توی استوری بعد، حتماً سیوش کنید چون فقط ۲۴ ساعت فعاله!»"""
      }

      ContentType.THREAD -> {
        """۲/۶ | مسئله اول: درک اشتباه از مبانی
اکثر افراد در حوزه ${niche.nameFa} بدون داشتن استراتژی مشخص، مستقیماً وارد عمل میشن و سریع خسته میشن.

۳/۶ | راهکار عملیاتی چیست؟
برای شروع کار با $topic، تنها به یک ساختار سه لایه‌ای نیاز دارید:
• لایه ورودی: جمع‌آوری داده و ایده
• لایه پردازش: بهینه‌سازی بر اساس نیاز
• لایه بازخورد: سنجش تعامل و بهبود

۴/۶ | ابزار پیشنهادی
استفاده از سیستم‌های هوشمند مدیریت و تولید محتوا باعث صرفه‌جویی حداقل ۱۰ ساعت در هفته برای شما خواهد شد.

۵/۶ | نکته تجربی شخصی
هرگز یک روند خوب رو قبل از دیدن اثر تجمیعی آن متوقف نکنید. صبر و پایداری کلید اصلی است."""
      }

      ContentType.BLOG_POST -> {
        """مقدمه:
در جهان پرشتاب کنونی، تسلط بر $topic به یک مزیت رقابتی غیرقابل انکار در حوزه ${niche.nameFa} تبدیل شده است. بسیاری از صاحبان کسب‌وکار و علاقه‌مندان به دلیل حجم اطلاعات متناقض دچار سردرگمی می‌شوند.

سرفصل اول (H2): ضرورت و اهمیت پرداختن به $topic
چرا باید این مفهوم را جدی بگیریم؟ تحقیقات نشان می‌دهد رعایت این استانداردها موجب ارتقای چشمگیر نرخ رضایت و رشد تصاعدی می‌شود.

سرفصل دوم (H2): مراحل اجرایی گام‌به‌گام
۱. تحلیل مقدماتی و تعیین اهداف هوشمندانه (SMART)
۲. پیاده‌سازی تکنیک‌های کاربردی با تکیه بر ابزارهای هوش مصنوعی
۳. ارزیابی شاخص‌های کلیدی عملکرد (KPIs)

جمع‌بندی:
همان‌طور که مرور شد، موفقیت در این زمینه حاصل پیوستگی، یادگیری مداوم و انعطاف‌پذیری در پیاده‌سازی متدولوژی‌های روز است."""
      }

      ContentType.EMAIL_MARKETING -> {
        """سلام دوست گرامی،

امیدوارم هفته فوق‌العاده‌ای را سپری کرده باشید.

امروز می‌خواستم دسترسی مستقیم به چک‌لیست کاربردی «$topic» را با شما به اشتراک بگذارم. در حوزه ${niche.nameFa}، چالش‌های متعددی پیش روی ما قرار دارد، اما با استفاده از این چارچوب عملیاتی می‌توانید مسیر خود را بسیار کوتاه‌تر کنید:

• دسترسی به نقشه راه گام‌به‌گام
• معرفی ابزارهای منتخب و میان‌برها
• نمونه‌های موردی موفق پیاده‌سازی شده

اگر تمایل دارید این تحول را از همین امروز در کسب‌وکار و مهارت‌های خود ایجاد کنید، روی دکمه زیر کلیک کنید."""
      }

      ContentType.PRODUCT_DESCRIPTION -> {
        """معرفی اجمالی:
محصول و راهکار جامع «$topic»، با طراحی پیشرفته و هماهنگ با نیازهای تخصصی فعالان حوزه ${niche.nameFa} تولید شده است.

ویژگی‌های برجسته:
✔️ کیفیت ساخت ممتاز و منطبق با استانداردهای بین‌المللی
✔️ رابط کاربری بسیار ساده بدون نیاز به پیش‌نیازهای پیچیده
✔️ پشتیبانی مداوم و به‌روزرسانی‌های منظم
✔️ صرفه‌جویی تضمین‌شده در هزینه و زمان شما

برای چه کسانی مناسب است؟
تمامی افرادی که به دنبال رشد مهارت، ارتقای عملکرد کاری و خلق خروجی حرفه‌ای هستند."""
      }
    }
  }

  private fun generateCta(type: ContentType, tone: ContentTone): String {
    return when (type) {
      ContentType.INSTAGRAM_POST -> "📌 این پست رو ذخیره (Save) کن تا سر فرصت گام‌هاش رو پیاده کنی، و بفرست برای دوستت که بهش نیاز داره! ❤️"
      ContentType.CAPTION -> "💬 نظر شما چیه؟ در کامنت‌ها بنویسید تا با هم بررسی کنیم. راستی یادت نره این پست رو لایک کنی!"
      ContentType.REELS_SCRIPT -> "🔥 اگه از این ترفند خوشت اومد، پیج رو فالو داشته باش چون هر روز ترفندهای دست اول برات دارم!"
      ContentType.INSTAGRAM_STORY -> "👉 همین الان روی استیکر لینک کلیک کن یا دایرکت پیام بده تا راهنما رو برات بفرستم."
      ContentType.THREAD -> "🔁 اگر این رشته برات مفید بود، با ریتوییت کردن به دیگران هم کمک کن تا یاد بگیرند. نظرت هم برام بنویس!"
      ContentType.BLOG_POST -> "📢 سوالات و تجربیات خود را در بخش نظرات مطرح کنید؛ کارشناسان ما به تمامی دیدگاه‌ها پاسخ خواهند داد."
      ContentType.EMAIL_MARKETING -> "🔗 [روی این لینک کلیک کنید و فایل اختصاصی را دریافت نمایید]"
      ContentType.PRODUCT_DESCRIPTION -> "🛒 هم‌اکنون با تخفیف ویژه خرید کنید | ضمانت بازگشت وجه تا ۷ روز"
    }
  }

  private fun generateHashtags(topic: String, niche: Niche, type: ContentType): List<String> {
    val cleanTopicTag = topic
      .replace(" ", "_")
      .replace("،", "")
      .replace("؟", "")
      .replace("!", "")
      .take(20)

    val baseTags = mutableListOf(
      "#کانتنتینو",
      "#تولید_محتوا",
      "#هوش_مصنوعی",
      "#محتوای_جذاب"
    )

    when (niche.id) {
      "tech_ai" -> baseTags.addAll(listOf("#تکنولوژی", "#هوش_مصنوعی_فارسی", "#فناوری_روز", "#دیجیتال"))
      "business_marketing" -> baseTags.addAll(listOf("#دیجیتال_مارکتینگ", "#کسب_و_کار", "#فروش_آنلاین", "#رشد_کسب_و_کار"))
      "lifestyle_wellness" -> baseTags.addAll(listOf("#سبک_زندگی", "#سلامتی", "#ورزش_در_خانه", "#روتین_روزانه"))
      "education_self_dev" -> baseTags.addAll(listOf("#توسعه_فردی", "#یادگیری", "#موفقیت", "#کتابخوانی"))
      "travel_tourism" -> baseTags.addAll(listOf("#ایرانگردی", "#سفر", "#گردشگری", "#طبیعت_گردی"))
      "fashion_beauty" -> baseTags.addAll(listOf("#استایل", "#مد_و_فشن", "#مراقبت_پوست", "#زیبایی"))
      "food_cooking" -> baseTags.addAll(listOf("#آشپزی", "#کافه_گردی", "#دستور_پخت", "#خوشمزه"))
      "real_estate_decor" -> baseTags.addAll(listOf("#دکوراسیون_داخلی", "#املاک", "#معماری", "#خانه_مدرن"))
      "finance_crypto" -> baseTags.addAll(listOf("#سرمایه_گذاری", "#مدیریت_مالی", "#پس_انداز", "#اقتصاد"))
    }

    if (cleanTopicTag.length > 2) {
      baseTags.add(0, "#$cleanTopicTag")
    }

    return baseTags.take(8)
  }
}
