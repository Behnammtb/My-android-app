package com.example

import com.example.generator.PersianContentEngine
import com.example.model.ContentTone
import com.example.model.ContentType
import com.example.model.NicheRepository
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentGeneratorTest {

  @Test
  fun testPersianContentGeneration() {
    val niche = NicheRepository.defaultNiche
    val content = PersianContentEngine.generate(
      topic = "تولید محتوا با هوش مصنوعی",
      niche = niche,
      contentType = ContentType.INSTAGRAM_POST,
      tone = ContentTone.FRIENDLY
    )

    assertNotNull(content)
    assertFalse(content.id.isEmpty())
    assertTrue(content.titleFa.contains("تولید محتوا با هوش مصنوعی"))
    assertTrue(content.bodyFa.isNotEmpty())
    assertTrue(content.hookFa.isNotEmpty())
    assertTrue(content.callToActionFa.isNotEmpty())
    assertTrue(content.hashtags.isNotEmpty())
  }
}
